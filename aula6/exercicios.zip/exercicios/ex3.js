let num = 344

num % 2 == 0 && console.log("Par") 
num % 2 != 0 && console.log("Ímpar") 