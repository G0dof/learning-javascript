let dia = 7;

dia == 1 && console.log("1 - Domingo");
dia == 2 && console.log("2 - Segunda");
dia == 3 && console.log("3 - Terça");
dia == 4 && console.log("4 - Quarta");
dia == 5 && console.log("5 - Quinta");
dia == 6 && console.log("6 - Sexta");
dia == 7 && console.log("7 - Sábado");
