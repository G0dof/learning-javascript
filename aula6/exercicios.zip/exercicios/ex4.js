let base = 2;
let expoente = 5;
let mult = 1;

for (let i = 0; i < expoente; i++) mult *= base;

console.log(mult);