let letra = "a";

//verify consonant or vowel

if (
    letra == "a" ||
    letra == "e" ||
    letra == "i" ||
    letra == "o" ||
    letra == "u"
) {
    console.log("Esta letra é vogal");
} else {
    console.log("Esta letra é consoante");
}
